# Script 3 (50 pts)
# 1. Define a Videogame Class:
#     Attributes: Include attributes for title, year, genre, and platform.
#     Methods:
#         print_info(): Prints the complete information of the video game in a readable format.
# 2. Open and read the contents of videogames.csv, where each line contains details such as title, year,
# genre, and platform.
# 3. Make a function name print_list_of_videogames that takes one argument. This argument is the list
# of Videogame objects and prints each video game's details using the print_info method.
# 4. Make a function name amount_of_games_per_platform that takes one argument. This argument is
# the list of Videogame objects and prints the count of video games per platform.
# 5. Make a function called add_videogame that takes one argument. This argument is the list of
# Videogame objects.
#     This function prompts the user for details of a new video game, creates a Videogame object, and
#     appends it to the list.
# 6. Make a function called update_file that takes one argument. This argument is the list of Videogame
# objects and writes the updated list of video games back to the videogames.csv file.
# 7. Execute Functions:
#     Call print_list_of_videogames to display all video games.
#     Call amount_of_games_per_platform to see how many games each platform has.
#     Call add_videogame to add a new game to the collection.
#     Call update_file to save the updated list to the CSV file.\

import os

class Videogame:
    def __init__(self, title: str, year: int, genre: str, platform: str) -> None:
        self.title = title
        self.year = year
        self.genre =  genre
        self.platform = platform
    
    def print_info(self) -> None:
        print(f"Name: {self.title} Year: {self.year} Genre: {self.genre} Platform: {self.platform}")


games = []  # List to store the games

if os.path.isfile("videogames.csv"):
    with open("videogames.csv", "r") as file:
        for line in file:
            data = line.strip().split(",")
            videogame = Videogame(data[0], data[1], data[2], data[3])
            #print(data[0], data[1], data[2], data[3])
            games.append(videogame)

#games[1].print_info()

def print_list_videogames(games: list):
    for game in games:
        index = 0
        games[index].print_info()
        index =+ 1 
        print(f"\n")
    
# def amount_of_games_per_platform(games: list):
#     for game in games:
#         index = 0
#         if games[index]
#         games[index].print_info()
#         index =+ 1 
#         print(f"\n")

def add_videogame(title: str, year: int, genre: str, platform: str) -> Videogame:
    title = input("Enter the title of the company: ")
    year = int(input("Enter the title of the company: "))
    genre = input("Enter the genre of the company: ")
    platform = input("Enter the platform of the company: ")
    videogame = Videogame(title, year, genre, platform)
    return videogame


games.append(add_videogame())
print_list_videogames(games)